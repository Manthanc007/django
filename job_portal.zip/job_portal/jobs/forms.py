from django import forms
from .models import *


class JobListingForm(forms.ModelForm):
    class Meta:
        model = JobListing
        fields = [
            'user','title', 'company_name', 'employment_status', 'gender','category',
            'description', 'responsibilities', 'experience', 'job_location', 'Salary', 'application_deadline', 'published_on'
        ]
