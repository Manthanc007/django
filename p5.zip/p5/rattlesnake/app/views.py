from django.http import HttpResponse
from django.shortcuts import render
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from .models import Jobs

# Create your views here.

class JobsList(ListView):
    model = Jobs

class JobsDetail(DetailView):
    model = Jobs

class JobsCreate(CreateView):
    model = Jobs
    fields = ['jobRole', 'qualification', 'specialization', 'location', 'salary', 'apply_date']
    success_url = reverse_lazy('jobs_list')

class JobsUpdate(UpdateView):
    model = Jobs
    fields = ['jobRole', 'qualification', 'specialization', 'location', 'salary', 'apply_date']
    success_url = reverse_lazy('jobs_list')

class JobsDelete(DeleteView):
    model = Jobs
    success_url = reverse_lazy('jobs_list')