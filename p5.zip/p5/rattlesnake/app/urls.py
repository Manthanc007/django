from django.urls import path
from . import views

urlpatterns = [
    path('', views.JobsList.as_view(), name='jobs_list'),
    path('view/<int:pk>', views.JobsDetail.as_view(), name='jobs_detail'),
    path('new', views.JobsCreate.as_view(), name='jobs_new'),
    path('edit/<int:pk>', views.JobsUpdate.as_view(), name='jobs_edit'),
    path('delete/<int:pk>', views.JobsDelete.as_view(), name='jobs_delete'),
]