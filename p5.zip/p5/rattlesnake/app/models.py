from django.db import models
from django.urls import reverse

# Create your models here.
class Jobs(models.Model):
    jobRole = models.CharField(max_length=200, null=False)
    qualification = models.CharField(max_length=200, null=False)
    specialization = models.CharField(max_length=200, null=True)
    location = models.CharField(max_length=200, null=True)
    salary = models.IntegerField(default=0)
    apply_date=models.DateTimeField('date applied')

    def __str__(self):
        return self.jobRole

    def get_absolute_url(self):
        return reverse('jobs_edit', kwargs={'pk': self.pk})